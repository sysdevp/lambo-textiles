<?php
//error_reporting(0);
if($_SERVER['HTTP_HOST'] == 'localhost'){
	$server = "localhost";	
	$user = "root";			
	$pass = "";				
	$db = "vision";		
}

elseif($_SERVER['HTTP_HOST'] == 'http://visiontechtally.com/'){
	$server = "localhost";	
	$user = "visiovpy_vision";		
	$pass = "vision#@123";			
	$db = "visiovpy_vision";		
	
}

elseif($_SERVER['HTTP_HOST'] == 'www.visiontechtally.com'){
	$server = "localhost";	
	$user = "visiovpy_vision";		
	$pass = "vision#@123";			
	$db = "visiovpy_vision";		
	
}

elseif($_SERVER['HTTP_HOST'] == 'visiontechtally.com'){
	$server = "localhost";	
	$user = "visiovpy_vision";		
	$pass = "vision#@123";			
	$db = "visiovpy_vision";		
	
}

if (!mysql_connect($server, $user, $pass)){
	die('Could not connect: ' . mysql_error());
}
if(!mysql_select_db($db)){
	die('Could not select Database: ' . mysql_error());
}
date_default_timezone_set("Asia/Kolkata");
$date_time=date("Y-m-d h:i:s");
?> 