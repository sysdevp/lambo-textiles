<?php
session_start();
error_reporting(0);
$connect = mysql_connect("localhost" , "visiovpy_root" , "adminjegan") or die("could't connect");
 mysql_select_db("visiovpy_vtech") or die("could't connect db");

if ( isset($_GET['id']))

  $m = $_GET['id'];
	
	$sql= "select * from registation WHERE mob='$m'";
	$query=mysql_query($sql);
	if(mysql_num_rows($query)>0)
	{
	   $i=1;
	  while($row=mysql_fetch_object($query))
	   {
	?>
<html >
  <head>
    <meta charset="UTF-8">
    <title>Welcome <?php echo $row->username; ?></title> 
    <link rel="shortcut icon" type="image/x-icon" href="style/images/favicon.png">
    <link rel="stylesheet" href="css/reset.css">
<link rel='stylesheet prefetch' href='http://fonts.googleapis.com/css?family=Roboto:400,100,300,500,700,900|RobotoDraft:400,100,300,500,700,900'>
<link rel='stylesheet prefetch' href='http://maxcdn.bootstrapcdn.com/font-awesome/4.3.0/css/font-awesome.min.css'>
        <link rel="stylesheet" href="css/style.css">
  </head>
    <body>
    <h2><br/>
      <br/>
      <br/>
    </h2>
   <div> <h2 align="center">Thank you for Connecting us</h2></div>
    <h2><br/>
      <br/>
      <br/>
      <table width="1110" height="58" border="1">
        <tr>
          <td width="115" height="31">&nbsp;</td>
          <td width="338">&nbsp;</td>
          <td width="149">Name</td>
          <td width="352"><?php echo $row->username; ?></td>
          <td width="122">&nbsp;</td>
        </tr>
        <tr>
          <td height="19">&nbsp;</td>
          <td>&nbsp;</td>
          <td>Register Number </td>
          <td> AC1000<?php echo $row->id; ?></td>
          <td>&nbsp;</td>
        </tr>
      </table>
<br/>
<br/>
<br/>
<div> <h2 align="center"><a href="http://www.visiontechtally.com">HOME</a></h2></div>
	  
    <script src='http://cdnjs.cloudflare.com/ajax/libs/jquery/2.1.3/jquery.min.js'></script>
     <script src="js/index.js"></script> 
  </body>
</html>
<?php

}
}
?>