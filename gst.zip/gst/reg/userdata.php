<?php
session_start();
error_reporting(0);
if($_SESSION['username'])
{
?>
<html >
  <head>
    <meta charset="UTF-8">
    <title>VISIONTECH</title> 
  </head>

  <body>
  <?php
$con=mysql_connect('localhost','visiovpy_root','adminjegan')or die('error Connect to DB');
   mysql_select_db('visiovpy_vtech',$con) or die('Error Select DB');				   
     error_reporting(0);
	  $page=$_GET["page"];
	 
	 if($page=="" || $page=="1")	
	 {
	  $p=0;
	  }
	  else
	  {
	  $p=($page*10);
	  
	  }							 					 
?>


 <table align="center" width="979" border="0">
    <th width="969" scope="col">
	
	<table width="94%" border="1">
	
	 <tr>
          <td width="8%" bgcolor="#EDEDED">Name : </td>
	      <td width="18%" bgcolor="#EDEDED">Mobile Number : </td>
		  <td width="19%" bgcolor="#EDEDED">E-mail : </td>
          <td bgcolor="#EDEDED">company : </td>
		  <td bgcolor="#EDEDED">Desigination : </td>
		  <td bgcolor="#EDEDED">Tally serial Number : </td>
                  <td bgcolor="#EDEDED">Registration Number : </td>
    </tr>
	<?php
	$sql= "select * from registation limit $p,30";
	$query=mysql_query($sql);
	if(mysql_num_rows($query)>0)
	{
	   $i=1;
	  while($row=mysql_fetch_object($query))
	   {
	?>
	      <tr>
	      <td width="13%" ><?php echo $row->username; ?>
          <td width="17%" ><?php echo $row->mob; ?></td>
          <td width="25%"><?php echo $row->mail; ?></td>
        <td><?php echo $row->cname; ?></td>	
         <td><?php 
	     if ($row->opt==0)
		  {
		     echo "None";
			 }
			 else
			   if ($row->opt==1) 
			 {
		        echo "Owner";
			
			  } 
 else
			   if ($row->opt==2) 
			 {
		        echo "Accounts manager";
			
			  } 
 else
			   if ($row->opt==3) 
			 {
		        echo "Accountant";
			
			  } 

			  ?>   
          <td><?php echo $row->sno; ?></td>
<td width="25%">AC1000<?php echo $row->id; ?></td>
		   <?php
  }
  }
  ?>  
	    </tr></table>
<p align="right">
<?php
 $res1= mysql_query("select * from vtech");
		$cou=mysql_num_rows($res1);
	       $aa=$cou/($cou/2)+$page;	
	$a= ceil($aa);
	$lastn =ceil($cou/10)-1;
	$lstnn=($page+1);
	?> <a href="userdata.php?page=0">|&#8810;</a>
	
	  <a href="userdata.php?page=<?php 
	if($page==0)
	echo 0;
	else	
	echo $page-1; ?>">&lt;Previous Page</a> ..............
		
	     <a href="userdata.php?page=<?php
   if($page==$lastn)
	echo ceil($cou/10)-1; 
	else
	echo $page+1; ?>">Next Page&gt;</a> <a href="userdata.php?page=<?php echo ceil($cou/10)-1; ?>" style="text-decoration:none">&#8811;|</a></p>
  </table>

  <p align="center"><a href="logout.php">logout</a> &nbsp; &nbsp; &nbsp; <a href="excel.php">Download</a></p>
 
  </body>
  
  <?php
     }
else
  include 'error.php';
    
?>
</html>