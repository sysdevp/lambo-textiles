<?php
	header( "Content-Type: application/vnd.ms-excel" );
	header( "Content-disposition: attachment; filename=userlist.xls" );
	
	// print your data here. note the following:
	// - cells/columns are separated by tabs ("\t")
	// - rows are separated by newlines ("\n")
	
session_start();
error_reporting(0);
if($_SESSION['username'])
{
$con=mysql_connect('localhost','visiovpy_vision','vision#@123')or die('error Connect to DB');
mysql_select_db('visiovpy_vision',$con) or die('Error Select DB');

	$sql= "select * from registation";
	$query=mysql_query($sql);
	if(mysql_num_rows($query)>0)
	{
	   $i=1;
	   echo 'Name'. "\t" . 'Mobile Number' . "\t" . 'E-mail' . "\t" . 'company' . "\t" .'Desigination'."\t" .'Tally serial Number' .  "\t" . 'Members' . "\n";
	   echo ''. "\t" . '' . "\t" . '' . "\t" . '' . "\t" .''."\t" .''. "\t" .''."\n";
	  while($row=mysql_fetch_object($query))
	   {
	    if ($row->opt==0)
		  {
		      $D = None;
			 }
			 else
			   if ($row->opt==1) 
			 {
		         $D = Owner;
			
			  } 
 else
			   if ($row->opt==2) 
			 {
		         $D = Accounts." ".manager;
			
			  } 
 else
			   if ($row->opt==3) 
			 {
		        $D = Accountant;
			
			  } 
	echo "$row->username" . "\t" . "$row->mob" . "\t" . "$row->mail" ."\t" . "$row->cname" ."\t" . "$D" ."\t" . "$row->sno" ."\t" . "$row->memb" ."\n";
	
	}}
	
	}
else
  include 'error.php';
?>