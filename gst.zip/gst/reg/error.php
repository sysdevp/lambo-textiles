<?php
session_start();
error_reporting(0);
$username = $_POST['username'];
$password = $_POST['password'];
if($username&&$password)
{
 $connect = mysql_connect("localhost" , "visiovpy_root" , "adminjegan") or die("could't connect");
 mysql_select_db("visiovpy_vtech") or die("could't connect db");
 $query =mysql_query("SELECT * FROM adminuser WHERE username='$username'");
 $numrows = mysql_num_rows($query); 
 if($numrows !=0) 
 {
 while($row = mysql_fetch_assoc($query))
{
   $dbusername=$row['username'];
   $dbpassword=$row['password'];
} 
 if($dbusername==$username&&$dbpassword==$password)
 {
  header('Location:userdata.php');
 $_SESSION['username']=$username;
 }
else {

 echo "<script>alert('Hello $username your  password is incorrect');</script>";
    }
}
else{
 echo "<script>alert('User $username does nott exist');</script>";
    }
}
else {
echo "<script>alert('please enter your username and password');</script>";
}
?>
<!DOCTYPE html>
<html >
  <head>
    <meta charset="UTF-8">
    <title>null</title>  
    <link rel="shortcut icon" type="image/x-icon" href="style/images/favicon.png">
    <link rel="stylesheet" href="css/reset.css">
    <link rel='stylesheet prefetch' href='http://fonts.googleapis.com/css?family=Roboto:400,100,300,500,700,900|RobotoDraft:400,100,300,500,700,900'>
<link rel='stylesheet prefetch' href='http://maxcdn.bootstrapcdn.com/font-awesome/4.3.0/css/font-awesome.min.css'>
        <link rel="stylesheet" href="css/style.css">   
  </head>
  <body>
 <body>
<div class="pen-title">
</div>
<!-- Form Module-->
<div class="module form-module">
<div class="form">
	</div>
  <div class="form ">
   <h2>User login</h2>
    <form action="error.php" method="post">
      <input type="text" name="username" placeholder="Username"/>
      <input type="password" name="password" placeholder="Password"/>
      <button>Login</button>
    </form>
  </div>
  
  </div>
  <div class="cta"><a href=""></a></div>
</div>
    <script src='http://cdnjs.cloudflare.com/ajax/libs/jquery/2.1.3/jquery.min.js'></script>
     <script src="js/index.js"></script>  
  </body>
</html>

