<html >
  <head>
    <meta charset="UTF-8">
    <title>VISIONTECH</title> 
    <link rel="shortcut icon" type="image/x-icon" href="style/images/favicon.png">
    <link rel="stylesheet" href="css/reset.css">
<link rel='stylesheet prefetch' href='http://fonts.googleapis.com/css?family=Roboto:400,100,300,500,700,900|RobotoDraft:400,100,300,500,700,900'>
<link rel='stylesheet prefetch' href='http://maxcdn.bootstrapcdn.com/font-awesome/4.3.0/css/font-awesome.min.css'>
        <link rel="stylesheet" href="css/style.css">
  </head>
    <body>
<?php
          header( "refresh:5;url=VISIONGST.pdf" );
         
?>
    <h2><br/>
      <br/>
      <br/>
      </h2>
   <div> <h2 align="center">Thank you for visiting our Vision Tech</h2></div>
    <h2><br/>
      <br/>
      <br/> 
    </h2>

    <p align="center">Your download will start with in <span id="counter">10</span> second(s).</p>
<script type="text/javascript">
function countdown() {
    var i = document.getElementById('counter');
    if (parseInt(i.innerHTML)<=2) {
        location.href = 'index.php';
    }
    i.innerHTML = parseInt(i.innerHTML)-1;
}
setInterval(function(){ countdown(); },1000);
</script>

    <br/>
    <br/> 
 <p align="center"> or click <a href="Location:VISIONGST.pdf">here</a> to download</p>
  <br/>
  <br/>
<p align="center"> For HSN File click <a href="Location:vhsn.pdf">here</a> to download</p>
<br/>
  <br/>
 <p align="center"><a href="index.php">Home</a></p>


    <script src='http://cdnjs.cloudflare.com/ajax/libs/jquery/2.1.3/jquery.min.js'></script>
     <script src="js/index.js"></script> 
  </body>
</html>
