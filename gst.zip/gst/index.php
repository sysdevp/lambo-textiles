<html >
  <head>
    <meta charset="UTF-8">
    <title>VISIONTECH</title> 
    <link rel="shortcut icon" type="image/x-icon" href="style/images/favicon.png">
    <link rel="stylesheet" href="css/reset.css">
<link rel='stylesheet prefetch' href='http://fonts.googleapis.com/css?family=Roboto:400,100,300,500,700,900|RobotoDraft:400,100,300,500,700,900'>
<link rel='stylesheet prefetch' href='http://maxcdn.bootstrapcdn.com/font-awesome/4.3.0/css/font-awesome.min.css'>
        <link rel="stylesheet" href="css/style.css">   
  </head>

  <body>
<div class="pen-title">
<span>ACCOUNTS <i class='fa fa-paint-brush'></i> +  </i> AUDITOR </i> =  </i><i class='fa fa-paint-brush'>TALLY</i></span>
</div>
<!-- Form Module-->
<div class="module form-module">
<div class="form">
</div>

  <div class="form ">
  
   <h2>Submit Your Details</h2>
    <form action="upload.php" method="post">
      <input type="text" name="username" placeholder="Your name"/>
      <input type="number" name="mob" placeholder="Mobile Number"/>
	  <input type="email" name="mail" placeholder="E-mail"/>
	  <input type="text" name="cname" placeholder="Company Name"/>
	  <select name="opt" style="width:240px; height:35px;">
	           <option selected disabled>Choose one</option>
			   <option value="1">Owner</option>
	           <option value="2">Accounts Manager</option>
			   <option value="3">Accountant</option>
        </select>
		<br/><br/>
	  <input type="number" name="sno" placeholder="Tally Serial No"/>
      <input type="submit" value="Download" name="add">
    </form>
  </div>
  
  </div>
  <div class="cta"><a href=""></a></div>
</div>
    <script src='http://cdnjs.cloudflare.com/ajax/libs/jquery/2.1.3/jquery.min.js'></script>
     <script src="js/index.js"></script> 
  </body>
</html>