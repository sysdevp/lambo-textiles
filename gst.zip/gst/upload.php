<?php
session_start();
error_reporting(0);
$con=mysql_connect('localhost','visiovpy_vision','vision#@123')or die('error Connect to DB');
mysql_select_db('visiovpy_vision',$con) or die('Please Reload again');
?>
<?php
if (isset($_POST['add']))
      {

                                                         $username=$_POST['username'];
			                                 $mob=$_POST['mob'];
							 $mail=$_POST['mail'];
							 $cname=$_POST['cname'];
							 $sno= $_POST['sno'];
							 $opt=$_POST['opt'];					 

	            $query=mysql_query("SELECT * FROM vtech WHERE mail='".$mail."'");
                 $numrows=mysql_num_rows($query);	
				 
	   if($mail && $mob !== "" && $sno !== "" && $username !== "" && $cname !== "") 
	     {
		      if($numrows==0) 			 
				   $sql="insert into vtech(username,mob,mail,cname,opt,sno) values('$username','$mob','$mail','$cname','$opt','$sno')";
                     $result=mysql_query($sql); 
				   if ($result)
	
				   {
				      header('Location:user.php');
				  }
				  
				  else 
				     if ($mob == "9790089653")
					 
					   header('Location:admin.php');
				 else
				 
				 {
					    header('Location:user.php');
						 
						 }
		 }
	
			  else 
				{
				  echo "<script>alert('Please fill all Fields');
				  window.location.href='index.php';
				  </script> ";
				 
	            }
    			
			} 
?>